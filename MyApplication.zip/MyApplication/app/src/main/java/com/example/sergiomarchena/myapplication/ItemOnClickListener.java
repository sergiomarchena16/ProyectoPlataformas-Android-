package com.example.sergiomarchena.myapplication;

import android.view.View;

/**
 * Created by SergioMarchena on 3/14/18.
 */

public interface ItemOnClickListener {

    void OnClick(View view, int position, boolean isLongClick);
}
