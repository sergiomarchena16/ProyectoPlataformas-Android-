package com.example.sergiomarchena.myapplication.Common;

import com.example.sergiomarchena.myapplication.Model.User;

/**
 * Created by SergioMarchena on 3/14/18.
 */

public class Common {

    public static User currentUser;
}
